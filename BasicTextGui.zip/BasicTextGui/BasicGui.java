
/**
 * @author Calum Watson 
 * @version 23/03/2017
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;

public class BasicGui implements ActionListener 
{
    // Default filename to use for saving and loading files
    // Possible improvement: replace with a FileChooser
    private final static String DEFAULT_FILENAME = "basicgui.txt";
    private int GRID_SIZE = 6;
    private static JButton button;
    private static JLabel label1, label2; 
    private static JTextArea textfield1, textfield2;

    /**
     * Create the Menu
     */
    public JMenuBar createMenu() 
    {
        JMenuBar menuBar  = new JMenuBar();;
        JMenu menu = new JMenu("Menu");
        JMenuItem menuItem;

        menuBar.add(menu);

        // A group of JMenuItems. You can create other menu items here if desired
        menuItem = new JMenuItem("Menu Option 1");
        menuItem.addActionListener(this);
        menu.add(menuItem);

        menuItem = new JMenuItem("Menu Option 2");
        menuItem.addActionListener(this);
        menu.add(menuItem);

        //a submenu
        menu.addSeparator();
        return menuBar;
    }

    /**
     * Creates the basic contentpane
     */
    public Container createContentPane() 
    {
        /* Create a panel to add components into 
         * Look up layouts to see how to plce items in a nicer way
         */
        JPanel panel = new JPanel();

        /* Create a label and add to the panel */

        /* Create a text field and add to the panel */
        textfield1 = new JTextArea("Enter word or phrase here...");
        textfield1.setRows(5);
        textfield1.setColumns(40);
        panel.add(textfield1);

        /* Create a text field, change the font and add to the panel */
        textfield2 = new JTextArea("Translation will show here...");
        textfield2.setRows(5);
        textfield2.setColumns(40);
        panel.add(textfield2);

        return panel;
    }

    /**
     * Creates the contentpane containing the button and drop down menus
     */
    public Container createContentPaneButtons()
    {

        JPanel panel = new JPanel();

        String[] choices = {"English","French", "Spanish","Russian","Italian","Gaelic"};

        final JComboBox<String> nlChoice = new JComboBox<String>(choices);

        nlChoice.setVisible(true);
        

        // Create a command button
        button = new JButton("Translate");

        // Add an action listner to respond to the button clicks
        button.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent e)
                {
                    // Handles the button clicks here
                    System.out.println("JButton clicked");
                } 
            });

        final JComboBox<String> tlChoice = new JComboBox<String>(choices);
        tlChoice.setVisible(true);
        
        panel.add(nlChoice);
        panel.add(button);
        panel.add(tlChoice);

        return panel;
    }

    /**
     * This method handles events from the Menu items.
     *
     */
    public void actionPerformed(ActionEvent e) 
    {
        String classname = getClassName(e.getSource());
        JComponent component = (JComponent)(e.getSource());

        if (classname.equals("JMenuItem"))
        {
            JMenuItem menusource = (JMenuItem)(e.getSource());
            String menutext  = menusource.getText();

            // Determine which menu option was chosen
            if (menutext.equals("Menu Option 1"))
            {
                /* BasicGUI    Add your code here to handle a menu option */
                System.out.println("Menu Option 1 selected");
            }
            else if (menutext.equals("Menu Option 2"))
            {
                /* BasicGUI    Add your code here to handle a menu option */
                System.out.println("Menu Option 2 selected");
            }
        }
    }

    /**
     *  Returns the class name
     */
    protected String getClassName(Object o) 
    {
        String classString = o.getClass().getName();
        int dotIndex = classString.lastIndexOf(".");
        return classString.substring(dotIndex+1);
    }

    /**
     * Create the GUI and show it.
     * For thread safety, this method should be invoked from the event-dispatching thread.
     */
    private static void createAndShowGUI() 
    {
        // Create and set up the window.
        JFrame frame = new JFrame("GO-GO-GADGET TRANSLATOR");
        BasicGui basicgui = new BasicGui();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //Create a panel and add components to it.
        JPanel contentPane = new JPanel(new BorderLayout());

        contentPane.add(basicgui.createContentPaneButtons(), BorderLayout.CENTER);
        contentPane.add(basicgui.createContentPane(), BorderLayout.NORTH);
        
        // Create and set up the content pane.
        frame.setJMenuBar(basicgui.createMenu());
        frame.setContentPane(contentPane); 
        
        // Display the window, setting the size
        frame.setSize(1000, 300);
        
        frame.setVisible(true);
    }

    /**
     * This is a standard main function for a Java GUI
     */
    public static void main(String[] args) 
    {
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable() 
            {
                public void run() 
                {
                    createAndShowGUI();
                }
            });
    }
}


